# BLINK profile, nutrition, and route update

## What will change
- Remove the fake Dynamic Island, all face/eye controls, animations, and simulated tube notifications from the HTML interface while leaving Android's real notification service intact.
- Add one compact shared profile for male, 19 years, 55 kg, 170 cm, six training days, and muscle-gain/hypertrophy; edits will immediately recalculate calorie, macro, hydration, and related targets throughout BLINK.
- Add the listed daily diet as a single preset with serving ranges/options, including the guava-or-amla choice, and guard against adding the same preset twice.
- Replace the current Live Route/orbit display with a small game-like map showing the current position, completed stops, and next destination.
- Refine spacing and visual hierarchy for a cleaner mobile view without changing the existing bottom navigation or other tools.

## Verification
- Check the mobile preview at 450×845.
- Edit the profile and confirm shared targets change.
- Add the daily diet once, confirm totals update, and confirm a second tap does not duplicate it.
- Open Route and verify the map reflects the current/next schedule stop.
- Confirm no fake island, face, eye, or simulated notification UI remains and the project reports a clean build.

## Technical details
- Keep the existing single-file BLINK data model and local device persistence.
- Preserve real Android foreground notifications and remove only web-based simulated notification code and markup.
