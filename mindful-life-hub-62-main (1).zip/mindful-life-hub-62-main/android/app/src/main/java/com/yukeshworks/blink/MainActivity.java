package com.yukeshworks.blink;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.webkit.JavascriptInterface;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {
	private boolean waitingForOverlayPermission;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		getBridge().getWebView().addJavascriptInterface(new OverlayBridge(this), "BlinkOverlay");
	}

	@Override
	public void onResume() {
		super.onResume();
		if (waitingForOverlayPermission && Settings.canDrawOverlays(this)) {
			waitingForOverlayPermission = false;
			ScreenEyesService.start(this);
		}
	}

	private void requestOverlayPermission() {
		if (Settings.canDrawOverlays(this)) {
			ScreenEyesService.start(this);
			return;
		}
		waitingForOverlayPermission = true;
		startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
			Uri.parse("package:" + getPackageName())));
	}

	private static final class OverlayBridge {
		private final MainActivity activity;

		OverlayBridge(MainActivity activity) { this.activity = activity; }

		@JavascriptInterface
		public void enableScreenEyes() { activity.runOnUiThread(activity::requestOverlayPermission); }

		@JavascriptInterface
		public void stopScreenEyes() { activity.runOnUiThread(() -> ScreenEyesService.stop(activity)); }

		@JavascriptInterface
		public void updateScreenEyes(int x, int y, int length, int width, int curve, String mood, String background) {
			activity.runOnUiThread(() -> ScreenEyesService.update(activity, x, y, length, width, curve, mood, background));
		}
	}
}
