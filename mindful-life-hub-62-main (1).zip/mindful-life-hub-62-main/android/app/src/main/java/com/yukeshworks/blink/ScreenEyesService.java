package com.yukeshworks.blink;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.os.Build;
import android.os.IBinder;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import androidx.annotation.Nullable;
import androidx.core.app.NotificationCompat;

import org.json.JSONObject;

public class ScreenEyesService extends Service {
    private static final String CHANNEL_ID = "screen_eyes";
    private static final int NOTIFICATION_ID = 7001;
    private static final String ACTION_UPDATE = "com.yukeshworks.blink.UPDATE";
    private static final String ACTION_STOP = "com.yukeshworks.blink.STOP";
    private WindowManager windowManager;
    private OverlayWebView overlayView;
    private WindowManager.LayoutParams layoutParams;
    private int x = 50, y = 10, length = 70, widthValue = 65, curve = 50;
    private String mood = "neutral";
    private String background = "transparent";

    public static void start(Context context) {
        if (!Settings.canDrawOverlays(context)) return;
        Intent intent = new Intent(context, ScreenEyesService.class);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) context.startForegroundService(intent);
        else context.startService(intent);
    }

    public static void stop(Context context) {
        context.stopService(new Intent(context, ScreenEyesService.class));
    }

    public static void update(Context context, int x, int y, int length, int width, int curve, String mood, String background) {
        Intent intent = new Intent(context, ScreenEyesService.class).setAction(ACTION_UPDATE)
            .putExtra("x", x).putExtra("y", y).putExtra("length", length)
            .putExtra("width", width).putExtra("curve", curve).putExtra("mood", mood)
            .putExtra("background", background);
        if (!Settings.canDrawOverlays(context)) return;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) context.startForegroundService(intent);
        else context.startService(intent);
    }

    @Override
    public void onCreate() {
        super.onCreate();
        createNotificationChannel();
        if (Build.VERSION.SDK_INT >= 34) startForeground(NOTIFICATION_ID, buildNotification(),
            android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
        else startForeground(NOTIFICATION_ID, buildNotification());

        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        overlayView = new OverlayWebView(this);
        layoutParams = new WindowManager.LayoutParams(200, 80,
            Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                : WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            android.graphics.PixelFormat.TRANSLUCENT);
        layoutParams.gravity = Gravity.TOP | Gravity.START;
        windowManager.addView(overlayView, layoutParams);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_STOP.equals(intent.getAction())) {
            stopSelf();
            return START_NOT_STICKY;
        }
        if (intent != null && ACTION_UPDATE.equals(intent.getAction())) {
            x = clamp(intent.getIntExtra("x", 50));
            y = clamp(intent.getIntExtra("y", 10));
            length = clamp(intent.getIntExtra("length", 70));
            widthValue = clamp(intent.getIntExtra("width", 65));
            curve = clamp(intent.getIntExtra("curve", 50));
            if (intent.getStringExtra("mood") != null) mood = intent.getStringExtra("mood");
            if ("black".equals(intent.getStringExtra("background"))) background = "black";
            else background = "transparent";
            overlayView.setState(length, widthValue, curve, mood, background);
            resizeAndMove();
        }
        return START_STICKY;
    }

    private int clamp(int value) { return Math.max(1, Math.min(100, value)); }

    private void resizeAndMove() {
        int padding = "black".equals(background) ? 12 : 2;
        int width = 108 + Math.round(length * 1.25f) + padding * 2;
        int height = 24 + Math.round(widthValue * .32f) + padding * 2;
        layoutParams.width = width;
        layoutParams.height = height;
        int screenWidth = getResources().getDisplayMetrics().widthPixels;
        layoutParams.x = Math.max(0, Math.round((screenWidth - width) * x / 100f));
        layoutParams.y = Math.round(y * .64f);
        windowManager.updateViewLayout(overlayView, layoutParams);
    }

    private Notification buildNotification() {
        PendingIntent stopIntent = PendingIntent.getService(this, 1,
            new Intent(this, ScreenEyesService.class).setAction(ACTION_STOP),
            PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        return new NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setContentTitle("BLINK Screen Eyes")
            .setContentText("The original BLINK tube is visible above your screen")
            .setOngoing(true)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Stop Screen Eyes", stopIntent)
            .build();
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID, "Screen Eyes",
                NotificationManager.IMPORTANCE_LOW);
            getSystemService(NotificationManager.class).createNotificationChannel(channel);
        }
    }

    @Override
    public void onDestroy() {
        if (overlayView != null && windowManager != null) windowManager.removeView(overlayView);
        super.onDestroy();
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) { return null; }

    private static final class OverlayWebView extends WebView {
        private boolean loaded;
        private int length = 70, widthValue = 65, curve = 50;
        private String mood = "neutral";
        private String background = "transparent";

        OverlayWebView(Context context) {
            super(context);
            setBackgroundColor(Color.TRANSPARENT);
            setLayerType(View.LAYER_TYPE_HARDWARE, null);
            setOverScrollMode(View.OVER_SCROLL_NEVER);
            setVerticalScrollBarEnabled(false);
            setHorizontalScrollBarEnabled(false);
            WebSettings settings = getSettings();
            settings.setJavaScriptEnabled(true);
            settings.setAllowFileAccess(true);
            settings.setDomStorageEnabled(true);
            setWebViewClient(new WebViewClient() {
                @Override
                public void onPageFinished(WebView view, String url) {
                    loaded = true;
                    applyState();
                }
            });
            loadUrl("file:///android_asset/public/blink.html#screen-eyes");
        }

        void setState(int length, int width, int curve, String mood, String background) {
            this.length = length;
            this.widthValue = width;
            this.curve = curve;
            if (mood != null) this.mood = mood;
            if (background != null) this.background = background;
            applyState();
        }

        private void applyState() {
            if (!loaded) return;
            String backgroundColor = "black".equals(background) ? "#000000" : "transparent";
            String backgroundPadding = "black".equals(background) ? "12px" : "2px";
            String css = "html,body{margin:0!important;width:100%!important;height:100%!important;overflow:visible!important;background:" + backgroundColor + "!important}"
                + ".phone{width:100%!important;min-height:100%!important;height:100%!important;padding:" + backgroundPadding + "!important;background:" + backgroundColor + "!important;box-shadow:none!important}"
                + ".phone> *:not(#eyeIsland){display:none!important}"
                + "#eyeIsland{display:block!important;position:absolute!important;left:50%!important;top:50%!important;width:auto!important;height:auto!important;transform:translate(-50%,-50%)!important;pointer-events:none!important}"
                + "#eyePill{pointer-events:none!important;overflow:hidden!important;contain:paint!important;clip-path:inset(0 round var(--notch-curve))!important}"
                + "#eyeIsland[data-size] #eyePill{width:var(--notch-length)!important;height:var(--notch-width)!important;border-radius:var(--notch-curve)!important}";
            String script = "(function(){var s=document.createElement('style');s.textContent="
                + JSONObject.quote(css) + ";document.head.appendChild(s);"
                + "notchState={x:50,y:10,size:'medium',scale:50,curve:" + curve
                + ",length:" + length + ",width:" + widthValue + "};applyNotchPrefs();setEyeMood("
                + JSONObject.quote(mood) + ");})();";
            evaluateJavascript(script, null);
        }
    }
}