(() => {
  const post = (type, payload = {}) =>
    window.parent.postMessage({ source: "blink", type, ...payload }, "*");

  const textOf = (el) => (el?.textContent || "").trim().replace(/\s+/g, " ");

  function findGoogleSection() {
    const nodes = [...document.querySelectorAll("button, [role='button'], a")];
    const connect = nodes.find((el) => /^connect$/i.test(textOf(el)));
    if (!connect) return null;
    let section = connect.closest("div");
    for (let i = 0; i < 6 && section; i++, section = section.parentElement) {
      if (/google\s*sync/i.test(textOf(section))) return section;
    }
    return connect.parentElement;
  }

  function findConnectButton() {
    const section = findGoogleSection();
    if (!section) return null;
    return [...section.querySelectorAll("button, [role='button'], a")]
      .find((el) => /^connect$/i.test(textOf(el)));
  }

  function setStatus({ connected, loading = false, error = "" } = {}) {
    const section = findGoogleSection();
    if (!section) return;

    const button = findConnectButton();
    if (button) {
      button.textContent = loading ? "Connecting…" : connected ? "Connected" : "Connect";
      button.setAttribute("aria-busy", loading ? "true" : "false");
    }

    const errorNodes = [...section.querySelectorAll("*")].filter((el) =>
      /firebase isn't configured|firebase is not configured|public web settings|not connected/i.test(textOf(el)),
    );
    errorNodes.forEach((el) => {
      if (loading) {
        el.textContent = "Connecting to Google…";
      } else if (connected) {
        el.textContent = "Google account connected • BLINK data sync is active";
      } else if (error) {
        el.textContent = error;
      } else if (el.children.length === 0) {
        el.textContent = "Connect Google to sync your BLINK data";
      }
    });
  }

  function wire() {
    const button = findConnectButton();
    if (button && button.dataset.blinkFirebaseWired !== "1") {
      button.dataset.blinkFirebaseWired = "1";
      button.addEventListener("click", (event) => {
        event.preventDefault();
        event.stopImmediatePropagation();
        setStatus({ loading: true });
        post("BLINK_GOOGLE_SIGN_IN");
      }, true);
    }
  }

  window.addEventListener("message", (event) => {
    if (event.source !== window.parent || event.data?.source !== "blink-host") return;
    if (event.data.type === "BLINK_AUTH_RESULT") {
      if (event.data.ok && event.data.signedOut) {
        setStatus({ connected: false });
      } else if (event.data.ok) {
        setStatus({ connected: true });
      } else {
        setStatus({ connected: false, error: event.data.error || "Google Sync failed. Try again." });
      }
      wire();
    }
  });

  wire();
  new MutationObserver(wire).observe(document.documentElement, { childList: true, subtree: true });
  window.addEventListener("online", () => post("BLINK_SYNC_NOW"));
  window.addEventListener("load", () => post("BLINK_SYNC_NOW"));
})();