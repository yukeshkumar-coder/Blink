import { useEffect, useRef } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { FirebaseAuthentication } from "@capacitor-firebase/authentication";
import { initializeApp, getApps } from "firebase/app";
import {
  getAuth,
  GoogleAuthProvider,
  signInWithCredential,
  signOut as firebaseSignOut,
} from "firebase/auth";
import {
  collection,
  deleteDoc,
  doc,
  getDocs,
  getFirestore,
  setDoc,
  writeBatch,
} from "firebase/firestore";

const firebaseConfig = {
  apiKey: "AIzaSyD6X96xxyupuaY6z9C-cPp3McgNJ5lfj68",
  authDomain: "blink-8ac05.firebaseapp.com",
  projectId: "blink-8ac05",
  storageBucket: "blink-8ac05.firebasestorage.app",
  messagingSenderId: "807734030240",
  appId: "1:807734030240:web:885b2d2a07823aa99abec5",
};

const firebaseApp = getApps().length ? getApps()[0] : initializeApp(firebaseConfig);
const auth = getAuth(firebaseApp);
const db = getFirestore(firebaseApp);

const SYNC_COLLECTION = "blinkState";

function encodeKey(key: string) {
  return encodeURIComponent(key).replace(/\./g, "%2E");
}

function decodeKey(key: string) {
  return decodeURIComponent(key.replace(/%2E/g, "."));
}

function getFrameWindow(iframe: HTMLIFrameElement | null) {
  return iframe?.contentWindow ?? null;
}

function getLocalState(iframe: HTMLIFrameElement | null) {
  const storage = getFrameWindow(iframe)?.localStorage;
  if (!storage) return new Map<string, string>();
  const result = new Map<string, string>();
  for (let i = 0; i < storage.length; i++) {
    const key = storage.key(i);
    if (key) {
      const value = storage.getItem(key);
      if (value !== null) result.set(key, value);
    }
  }
  return result;
}

async function downloadCloudState(uid: string) {
  const snapshot = await getDocs(collection(db, "users", uid, SYNC_COLLECTION));
  const state = new Map<string, string>();
  snapshot.forEach((item) => {
    const data = item.data();
    if (typeof data.value === "string") state.set(decodeKey(item.id), data.value);
  });
  return state;
}

async function uploadLocalState(uid: string, iframe: HTMLIFrameElement | null) {
  const state = getLocalState(iframe);
  const batch = writeBatch(db);
  for (const [key, value] of state) {
    batch.set(doc(db, "users", uid, SYNC_COLLECTION, encodeKey(key)), {
      key,
      value,
      updatedAt: Date.now(),
    });
  }
  if (state.size) await batch.commit();
}

async function mergeAndSync(uid: string, iframe: HTMLIFrameElement | null) {
  const storage = getFrameWindow(iframe)?.localStorage;
  if (!storage) return;

  const cloud = await downloadCloudState(uid);
  const local = getLocalState(iframe);

  if (cloud.size > 0) {
    // On the first connection, cloud state becomes the source of truth on a
    // new device. Local-only keys are retained and then uploaded.
    for (const [key, value] of cloud) storage.setItem(key, value);
    for (const [key, value] of local) {
      if (!cloud.has(key)) storage.setItem(key, value);
    }
  }

  await uploadLocalState(uid, iframe);
  storage.setItem("blink.firebase.syncedUid", uid);
}

async function signIn() {
  const result = await FirebaseAuthentication.signInWithGoogle();
  const idToken = result.credential?.idToken;
  if (idToken) {
    const credential = GoogleAuthProvider.credential(idToken);
    await signInWithCredential(auth, credential);
  }
  return auth.currentUser ?? result.user ?? null;
}

async function handleMessage(
  event: MessageEvent,
  iframe: HTMLIFrameElement | null,
) {
  if (event.source !== getFrameWindow(iframe)) return;
  if (!event.data || event.data.source !== "blink") return;

  try {
    if (event.data.type === "BLINK_GOOGLE_SIGN_IN") {
      const user = await signIn();
      if (!user) throw new Error("Google sign-in did not return a user.");
      await mergeAndSync(user.uid, iframe);
      getFrameWindow(iframe)?.postMessage(
        {
          source: "blink-host",
          type: "BLINK_AUTH_RESULT",
          ok: true,
          user: {
            uid: user.uid,
            displayName: user.displayName ?? "",
            email: user.email ?? "",
            photoURL: user.photoURL ?? "",
          },
        },
        "*",
      );
    }

    if (event.data.type === "BLINK_GOOGLE_SIGN_OUT") {
      await FirebaseAuthentication.signOut();
      await firebaseSignOut(auth);
      getFrameWindow(iframe)?.postMessage(
        { source: "blink-host", type: "BLINK_AUTH_RESULT", ok: true, signedOut: true },
        "*",
      );
    }

    if (event.data.type === "BLINK_SYNC_NOW" && auth.currentUser) {
      await mergeAndSync(auth.currentUser.uid, iframe);
      getFrameWindow(iframe)?.postMessage(
        { source: "blink-host", type: "BLINK_SYNC_RESULT", ok: true },
        "*",
      );
    }
  } catch (error) {
    getFrameWindow(iframe)?.postMessage(
      {
        source: "blink-host",
        type: "BLINK_AUTH_RESULT",
        ok: false,
        error: error instanceof Error ? error.message : "Google Sync failed.",
      },
      "*",
    );
  }
}

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "BLINK — Your day, in focus" },
      { name: "description", content: "Diet, schedule, gym, body map, budget, roadmap and mind tools in one compact app." },
      { property: "og:title", content: "BLINK — Your day, in focus" },
      { property: "og:description", content: "Diet, schedule, gym, body map, budget, roadmap and mind tools in one compact app." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});

function Index() {
  const iframeRef = useRef<HTMLIFrameElement>(null);

  useEffect(() => {
    const listener = (event: MessageEvent) => {
      void handleMessage(event, iframeRef.current);
    };
    window.addEventListener("message", listener);

    const syncExistingSession = async () => {
      if (!auth.currentUser) return;
      try {
        await mergeAndSync(auth.currentUser.uid, iframeRef.current);
        getFrameWindow(iframeRef.current)?.postMessage(
          {
            source: "blink-host",
            type: "BLINK_AUTH_RESULT",
            ok: true,
            user: {
              uid: auth.currentUser.uid,
              displayName: auth.currentUser.displayName ?? "",
              email: auth.currentUser.email ?? "",
              photoURL: auth.currentUser.photoURL ?? "",
            },
          },
          "*",
        );
      } catch {
        // The UI remains usable offline; sync retries on the next connection.
      }
    };

    void syncExistingSession();

    return () => window.removeEventListener("message", listener);
  }, []);

  return (
    <iframe
      ref={iframeRef}
      src="/blink.html"
      title="BLINK"
      className="fixed inset-0 h-screen w-screen border-0"
      allow="clipboard-read; clipboard-write"
    />
  );
}
