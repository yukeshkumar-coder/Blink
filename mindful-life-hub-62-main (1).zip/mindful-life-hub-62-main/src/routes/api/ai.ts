import { createFileRoute } from "@tanstack/react-router";

const N = ["kcal", "protein", "carb", "fat", "fiber", "calcium", "iron", "magnesium", "potassium", "vitD", "vitC", "vitA", "vitB12", "folate", "zinc", "selenium"];

const num = { type: ["number", "null"] };
const str = { type: ["string", "null"] };

const itemProps: Record<string, unknown> = {
  kind: { type: "string", enum: ["food", "expense", "event"] },
  name: { type: "string" },
  date: str,
  time: str,
  grams: num,
  amount: num,
  category: { type: ["string", "null"], enum: ["food", "supp", "care", "other", null] },
};

N.forEach((k) => (itemProps[k] = num));

const schema = {
  type: "object",
  additionalProperties: false,
  required: ["items"],
  properties: {
    items: {
      type: "array",
      items: {
        type: "object",
        additionalProperties: false,
        required: Object.keys(itemProps),
        properties: itemProps,
      },
    },
  },
};

type GeminiPart = {
  text?: string;
  inline_data?: {
    mime_type: string;
    data: string;
  };
};

function imageToGeminiPart(image: string): GeminiPart | null {
  const match = image.match(/^data:(image\/[a-zA-Z0-9.+-]+);base64,(.+)$/s);
  const mimeType = match?.[1];
  const data = match?.[2];
  if (!mimeType || !data) return null;

  return {
    inline_data: {
      mime_type: mimeType,
      data,
    },
  };
}

export const Route = createFileRoute("/api/ai")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        const key = process.env["GEMINI_API_KEY"];
        if (!key) {
          return Response.json(
            { error: "Gemini AI is not configured. Add GEMINI_API_KEY to the server environment." },
            { status: 500 },
          );
        }

        const {
          text = "",
          image = null,
          today = "",
        } = (await request.json()) as {
          text?: string;
          image?: string | null;
          today?: string;
        };

        if (!text && !image) {
          return Response.json({ error: "Add text or an image" }, { status: 400 });
        }

        if (String(text).length > 8000 || (image && image.length > 8_000_000)) {
          return Response.json({ error: "Input too large" }, { status: 400 });
        }

        const instructions = `You extract data for a personal tracker app. Today is ${today}. Return ONLY valid JSON matching the provided schema.

- kind "food": each food eaten/in a meal photo or diet plan meal. name, grams = estimated portion in grams, and nutrient values PER 100 g from standard food composition data (kcal, protein/carb/fat/fiber g, calcium/iron/magnesium/potassium/vitC/zinc mg, vitD/vitA/vitB12/folate/selenium µg). For a diet plan, also add "event" items for each meal time.
- kind "expense": purchases/receipts/bills. name, amount in INR (number), category food|supp(supplements)|care(personal care)|other, date.
- kind "event": timetable classes, schedules, workouts, tasks, reminders. name, date YYYY-MM-DD (expand weekly timetables into the next 7 days starting today), time HH:MM 24h.
- Use null for fields not relevant to the kind.
- Understand natural language such as "gym tomorrow 6pm".
- Do not invent quantities, dates, prices, or nutrient values when they cannot reasonably be inferred. Estimate food portions only when necessary and keep estimates plausible.`;

        const parts: GeminiPart[] = [
          { text: `${instructions}\n\nUser input:\n${text || "Extract everything from this image."}` },
        ];

        if (image) {
          const imagePart = imageToGeminiPart(image);
          if (!imagePart) {
            return Response.json(
              { error: "Unsupported image format. Send the image as a base64 data URL." },
              { status: 400 },
            );
          }
          parts.push(imagePart);
        }

        const res = await fetch(
          "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash-lite:generateContent",
          {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
              "x-goog-api-key": key,
            },
            body: JSON.stringify({
              contents: [{ role: "user", parts }],
              generationConfig: {
                responseMimeType: "application/json",
                responseSchema: schema,
                temperature: 0.2,
              },
            }),
          },
        );

        if (!res.ok) {
          let providerMessage = "";
          try {
            const errorBody = (await res.json()) as { error?: { message?: string } };
            providerMessage = errorBody.error?.message ?? "";
          } catch {
            // Keep the generic status-based message below.
          }

          const msg =
            res.status === 400
              ? `Gemini rejected the request${providerMessage ? `: ${providerMessage}` : "."}`
              : res.status === 401 || res.status === 403
                ? "Gemini API key is invalid or not authorized."
                : res.status === 429
                  ? "Gemini rate limit reached — try again shortly."
                  : `Gemini AI error (${res.status})`;

          return Response.json({ error: msg }, { status: res.status || 500 });
        }

        const payload = (await res.json()) as {
          candidates?: Array<{
            content?: {
              parts?: Array<{ text?: string }>;
            };
          }>;
        };

        const out = payload.candidates?.[0]?.content?.parts
          ?.map((part) => part.text ?? "")
          .join("")
          .trim();

        if (!out) {
          return Response.json({ error: "Gemini returned an empty response. Try again." }, { status: 502 });
        }

        try {
          return Response.json(JSON.parse(out));
        } catch {
          return Response.json({ error: "Gemini returned invalid JSON — try rephrasing." }, { status: 502 });
        }
      },
    },
  },
});
