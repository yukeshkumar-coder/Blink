# Zenful Life Dashboard

I have html code attached (main123.html). Remove the LIVE FACE EXPRESSIVE hero section first. I want a touch-sensitive background with neat, compact, and simple UI/UX design. I don't need over-scrolling, but if it is necessary keep it, don't remove required scrolling. Keep all the underlying tools and datasets (diet tracking, schedule, gym exercises, body map, budget, roadmap, mind) functioning cleanly.

This project was built with [Lovable](https://lovable.dev).

**Live app**: https://mindful-life-hub-62.lovable.app

## Build with Lovable

Continue developing this project in the [Lovable editor](https://lovable.dev/projects/309317e3-1f12-4ebf-b102-a9a33318c12b).

- **Ship faster**: describe what you want to build and Lovable handles the code.
- **Stay in sync**: every change made in Lovable is committed straight to this repository.
- **Full ownership**: this code is yours. Push to `main` on GitHub and your changes sync back into Lovable, ready for your next prompt.

## Development

Prefer working locally? You need Node.js and npm — [install with nvm](https://github.com/nvm-sh/nvm#installing-and-updating).

```sh
git clone <this-repository-url>
cd <repository-name>
npm i
npm run dev
```
